/**
 * server.c
 *
 * The server captures image frames from
 * axis cameras.
 * 
 */
/*************** HEADER FILES **************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <capture.h>
#include <sys/socket.h>
#include <arpa/inet.h>

/*************** MACRO DEFINITIONS *********/
/* Number of frames */
#define NUM_OF_FRAMES 1000

/* Maximum number of clients */
#define MAX_CLIENTS 5

/* Port number */
#define PORT_NUMBER 5016

/* Buffer size */
#define BUFF_SIZE 1024

/******** LOCAL FUNCTION DECLARATIONS ******/
static int server(void);

/********** FUNCTION DEFINITIONS ***********/
/**
 * server:
 *
 * Function which handles clients and captures
 * frames.
 *
 * @returns: EXIT_SUCCESS if success.
 *           EXIT_FAILURE if an error occurs. 
 */
static int server(void) {
  int sock_fd;
  int new_sock_fd;
  int cnt_frames = 0;
  int pid;
  int n;
  char buf_recv[BUFF_SIZE];
  char str[BUFF_SIZE];
  struct sockaddr_in serv_addr;
  struct sockaddr_in cli_addr;
  char *available_res;
  char *available_res_temp;
  void *data;
  size_t send_size;
  size_t size;
  socklen_t cli_len;
  media_stream *stream;
  media_frame *frame;

  /* Creating socket */
  sock_fd = socket(AF_INET, SOCK_STREAM, 0);

  /* Check socket descriptor status */
  if (sock_fd < 0) {
    syslog(LOG_ERR, "ERROR opening socket");
    return EXIT_FAILURE;
  }

  /* Initialize serv_addr memory to zero. */
  memset(&serv_addr, 0, sizeof(serv_addr));
 
  /* Set internet family to AF_NET (IPv4) */
  serv_addr.sin_family = AF_INET;

  /* Any IP address */
  serv_addr.sin_addr.s_addr = INADDR_ANY;

  /* Port address
   * (Host to network short)
   */
  serv_addr.sin_port = htons(PORT_NUMBER);

  /* Binds server address to socket */
  if (bind(sock_fd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
    syslog(LOG_ERR, "ERROR on binding.");
    return EXIT_FAILURE;
  }

  /* Listen to the socket for clients, Maximum 5 clients */
  listen(sock_fd, MAX_CLIENTS);
  cli_len = sizeof(cli_addr);

  /* Loop handler for clients */
  for (;;) {
    /* Accepting clients in new_sock_fd */
    new_sock_fd = accept(sock_fd, (struct sockaddr *) &cli_addr, &cli_len);

    /* Status of the new sock_fd */
    if (new_sock_fd < 0) {
      syslog(LOG_ERR, "ERROR on accept");
      return EXIT_FAILURE;
    }

    /* Create a child process */
    pid = fork();
    if (pid < 0) {
      syslog(LOG_ERR, "ERROR on fork");
      close(new_sock_fd);
      continue;
    }

    /* Child process created */
    if (pid == 0) {
      /* Get the available resolution */
      available_res_temp = malloc(BUFF_SIZE);
      memset(available_res_temp, 0, BUFF_SIZE);
      available_res = malloc(BUFF_SIZE);
      memset(available_res, 0, BUFF_SIZE);
      available_res_temp = capture_get_resolutions_list(0);
      syslog(LOG_INFO, "available res: %s", available_res_temp);

      /* Append '\n' in the end, so that client terminates
       * and parses the resolution list correctly
       */
      sprintf(available_res, "%s\n", available_res_temp);

      /* Pass the available resolution to client */
      n = write(new_sock_fd, available_res, strlen(available_res));

      /* Check the return status of write function */
      if (n < 0) {
        syslog(LOG_ERR, "Error in writing to socket");
      } else {
        syslog(LOG_INFO, "Write successfull");
      }

      /* Free the memory allocated for available resolution */
      free(available_res_temp);
      free(available_res);

      /* Wait for user resolution and fps */
      memset(buf_recv, 0, BUFF_SIZE);
      syslog(LOG_INFO, "Waiting for resolution and fps from client...");
      while((n = recv(new_sock_fd, buf_recv, BUFF_SIZE, 0)) > 0) {
        syslog(LOG_INFO, "String received from client: %s\n", buf_recv);
        break;
      }

      /* Form a string using user resolution and fps.
       * Append this str if any other data needed.
       * Ex: buf_recv contains resolution=1280x720&fps=15
       */
      snprintf(str, sizeof(str), "%s", buf_recv);

      /* Capture the stream */
      stream = capture_open_stream(IMAGE_JPEG, str);

      /* Loops to number of frames, default 10 */
      while(cnt_frames < NUM_OF_FRAMES) {
        /* Get the frame information */
        frame = capture_get_frame(stream);

        /* Get the frame data */
        data = capture_frame_data(frame);

        /* Get the frame size */
        size = capture_frame_size(frame);

        /* Send size and data to client */
        send_size = htonl(size);
        write(new_sock_fd, &send_size, sizeof(send_size));
        write(new_sock_fd, data, size);

        /* Free the allocated memory */
        capture_frame_free(frame);

        /* Increment the frame counter */
        cnt_frames++;
      }
      /* Close the stream */
      capture_close_stream(stream);

      /* Close the new sock_fd */
      close(new_sock_fd);
    } else {
      /* Close the new sock_fd */
      close(new_sock_fd);
    }
  }

  /* Close server socket */
  close(sock_fd);
 
  return EXIT_SUCCESS;
}

/**
 * main:
 *
 * Main function which triggers the
 * server function.
 *
 * @returns: EXIT_SUCCESS if success.
 */
int main(void) {

  if (!server()) {
    goto out;
  }

  return EXIT_SUCCESS;

out:
  return EXIT_FAILURE;  
}
